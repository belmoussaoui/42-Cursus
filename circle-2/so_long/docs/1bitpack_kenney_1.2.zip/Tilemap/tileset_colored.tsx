<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="2018.12.22" name="colored" tilewidth="16" tileheight="16" spacing="1" tilecount="1024" columns="32">
 <image source="tileset_legacy.png" width="543" height="543"/>
</tileset>
